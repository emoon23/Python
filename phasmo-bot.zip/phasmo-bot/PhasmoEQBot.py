################IMPORTS####################
import os
import discord
import random
import requests, json
import pyowm
##########################################


####################################
from dotenv import load_dotenv
from discord.ext.commands import Bot
from discord.ext import commands

load_dotenv()
# GET TOKEN
#TOKEN = 'Nzk0ODM3MzQ0NTQ0NDg5NTEy.X_An9g.S9B_RiEO3Lh_LpIWCnnrqqwPhcs'
GUILD = os.getenv('DISCORD_GUILD')
BOT_PREFIX = ("!", "?")

client = discord.Client()

bot = commands.Bot(command_prefix="!")


####################################
# Interactive commands with EQ-BOT

#####

"""
To run this script: Open powershell or bash (prefer powershell).
	Then in the command line: python .\PhasmoEQBot.py

"""

#####

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('Hello'):
        msg = 'Hello {@.author.mention}'.format(message)
        await message.channel.send('Hello Ghost Hunter')
    elif message.content.startswith('hello'):
        msg = 'Hey hey {0.author.mention}'.format(message)
        await message.channel.send('Hello there!')

    # EQ Bot Commands
    if message.content.startswith('!challenge'):
        # Equipment
        test_dict = {
            "O.G. :": " > Weak Flashlights only, 1 Book, 1 Photo, 1 Video, 1 Thermometer, 1 EMF, 1 Spirit Box, no pills",
            "HARDCORE:": " > Candles as only light source, no pills",
            "PLASMA N FIRE:": " > Glowsticks and Candle as light source",
            "MONK:": " > Crucifix, Smudge, and Salt for offense",
            "ONE LIGHT: " : " > Only 1 Ghost Hunter can equip a flashlight",
            }
        res = key, val = random.choice(list(test_dict.items()))
        await message.channel.send('CHALLENGE: ' + str(res))


@client.event
async def on_ready():
    print('Logged in as')
    print(client.user.name)
    print(client.user.id)
    print('--------')


client.run(TOKEN)
bot.run(TOKEN)
